'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  BookOpen, 
  Brain, 
  Clock, 
  Target, 
  TrendingUp, 
  FileText, 
  Zap, 
  Upload,
  Play,
  CheckCircle,
  AlertCircle,
  Lightbulb,
  Calendar,
  BarChart3
} from 'lucide-react'

interface LearningData {
  overview: {
    totalSessions: number;
    totalHours: number;
    averageSessionDuration: number;
    comprehensionRate: number;
    retentionRate: number;
    subjects: string[];
    currentStreak: number;
    longestStreak: number;
  };
  learningStyle: {
    visual: number;
    auditory: number;
    kinesthetic: number;
    reading: number;
    primary: string;
    recommendations: string[];
  };
  recentSessions: Array<{
    id: string;
    title: string;
    subject: string;
    duration: number;
    difficulty: number;
    comprehension: number;
    notes: string;
    date: string;
    tags: string[];
    flashcardsGenerated: number;
  }>;
  documents: Array<{
    id: string;
    title: string;
    type: string;
    pages: number;
    processed: boolean;
    summary: string;
    keyTopics: string[];
    readingProgress: number;
    lastAccessed: string;
    extractedInsights: number;
  }>;
  flashcards: {
    total: number;
    dueForReview: number;
    mastered: number;
    learning: number;
    difficult: number;
    averageAccuracy: number;
    nextReviewSession: string;
  };
  recommendations: {
    optimalStudyTime: string;
    optimalSessionLength: number;
    suggestedTopics: Array<{
      topic: string;
      reason: string;
      priority: string;
    }>;
    knowledgeGaps: string[];
  };
}

export default function LearningTab() {
  const [learningData, setLearningData] = useState<LearningData | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')

  useEffect(() => {
    loadLearningData()
  }, [])

  const loadLearningData = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/learning')
      if (!response.ok) {
        throw new Error('Failed to fetch learning data')
      }
      const data = await response.json()
      setLearningData(data)
    } catch (error) {
      console.error('Error loading learning data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleDocumentUpload = async () => {
    // Simulate document upload
    const fileInput = document.createElement('input')
    fileInput.type = 'file'
    fileInput.accept = '.pdf,.txt,.doc,.docx'
    fileInput.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (file) {
        try {
          const response = await fetch('/api/learning', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              action: 'process-document',
              data: {
                filename: file.name,
                content: 'Sample document content for processing'
              }
            })
          })

          if (response.ok) {
            const result = await response.json()
            console.log('Document processed:', result)
            // Refresh learning data
            loadLearningData()
          }
        } catch (error) {
          console.error('Error uploading document:', error)
        }
      }
    }
    fileInput.click()
  }

  const handleStartSession = async () => {
    try {
      const response = await fetch('/api/learning', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'start-session',
          data: {
            title: 'New Learning Session',
            subject: 'General',
            duration: 45
          }
        })
      })

      if (response.ok) {
        const result = await response.json()
        console.log('Session started:', result)
      }
    } catch (error) {
      console.error('Error starting session:', error)
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-purple-800/30 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="h-32 bg-purple-800/30 rounded"></div>
            <div className="h-32 bg-purple-800/30 rounded"></div>
            <div className="h-32 bg-purple-800/30 rounded"></div>
          </div>
        </div>
      </div>
    )
  }

  if (!learningData) return null

  return (
    <div className="space-y-6">
      {/* Learning Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
              <BookOpen className="w-4 h-4 mr-2" />
              Total Sessions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{learningData.overview.totalSessions}</div>
            <p className="text-purple-200 text-xs mt-1">
              {learningData.overview.currentStreak} day streak
            </p>
          </CardContent>
        </Card>

        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
              <Clock className="w-4 h-4 mr-2" />
              Learning Hours
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{learningData.overview.totalHours}</div>
            <p className="text-purple-200 text-xs mt-1">
              {learningData.overview.averageSessionDuration} min avg
            </p>
          </CardContent>
        </Card>

        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
              <Brain className="w-4 h-4 mr-2" />
              Comprehension
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              {Math.round(learningData.overview.comprehensionRate * 100)}%
            </div>
            <Progress value={learningData.overview.comprehensionRate * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>

        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
              <Target className="w-4 h-4 mr-2" />
              Retention
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              {Math.round(learningData.overview.retentionRate * 100)}%
            </div>
            <Progress value={learningData.overview.retentionRate * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 bg-black/30 border border-purple-700/30">
          <TabsTrigger value="overview" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Overview
          </TabsTrigger>
          <TabsTrigger value="sessions" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Sessions
          </TabsTrigger>
          <TabsTrigger value="documents" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Documents
          </TabsTrigger>
          <TabsTrigger value="flashcards" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Flashcards
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Learning Style */}
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-purple-400" />
                  Learning Style Analysis
                </CardTitle>
                <CardDescription className="text-purple-200">
                  Your optimal learning preferences
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <Badge className="bg-purple-600 text-white mb-4">
                      {learningData.learningStyle.primary}
                    </Badge>
                  </div>
                  <div className="space-y-3">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm">Visual</span>
                        <span className="text-white font-medium">{Math.round(learningData.learningStyle.visual * 100)}%</span>
                      </div>
                      <Progress value={learningData.learningStyle.visual * 100} className="h-2" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm">Auditory</span>
                        <span className="text-white font-medium">{Math.round(learningData.learningStyle.auditory * 100)}%</span>
                      </div>
                      <Progress value={learningData.learningStyle.auditory * 100} className="h-2" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm">Kinesthetic</span>
                        <span className="text-white font-medium">{Math.round(learningData.learningStyle.kinesthetic * 100)}%</span>
                      </div>
                      <Progress value={learningData.learningStyle.kinesthetic * 100} className="h-2" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm">Reading</span>
                        <span className="text-white font-medium">{Math.round(learningData.learningStyle.reading * 100)}%</span>
                      </div>
                      <Progress value={learningData.learningStyle.reading * 100} className="h-2" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recommendations */}
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Lightbulb className="w-5 h-5 mr-2 text-yellow-400" />
                  AI Recommendations
                </CardTitle>
                <CardDescription className="text-purple-200">
                  Personalized learning suggestions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 rounded-lg bg-purple-800/20 border border-purple-700/30">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-white font-medium">Optimal Study Time</span>
                      <Clock className="w-4 h-4 text-purple-400" />
                    </div>
                    <p className="text-purple-200 text-sm">{learningData.recommendations.optimalStudyTime}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-800/20 border border-purple-700/30">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-white font-medium">Session Length</span>
                      <Target className="w-4 h-4 text-purple-400" />
                    </div>
                    <p className="text-purple-200 text-sm">{learningData.recommendations.optimalSessionLength} minutes</p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-white font-medium">Suggested Topics</h4>
                    {learningData.recommendations.suggestedTopics.map((topic, index) => (
                      <div key={index} className="p-2 rounded-lg bg-purple-800/20 border border-purple-700/30">
                        <div className="flex items-center justify-between">
                          <span className="text-white text-sm">{topic.topic}</span>
                          <Badge variant={topic.priority === 'high' ? 'destructive' : 'secondary'} className="text-xs">
                            {topic.priority}
                          </Badge>
                        </div>
                        <p className="text-purple-200 text-xs mt-1">{topic.reason}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Sessions Tab */}
        <TabsContent value="sessions" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold text-white">Recent Learning Sessions</h3>
            <Button onClick={handleStartSession} className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              <Play className="w-4 h-4 mr-2" />
              Start Session
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {learningData.recentSessions.map((session) => (
              <Card key={session.id} className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="text-white text-lg">{session.title}</CardTitle>
                  <CardDescription className="text-purple-200">
                    {session.subject} • {new Date(session.date).toLocaleDateString()}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-purple-200 text-sm">Duration</span>
                      <span className="text-white font-medium">{session.duration} min</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-purple-200 text-sm">Comprehension</span>
                      <span className="text-white font-medium">{Math.round(session.comprehension * 100)}%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-purple-200 text-sm">Difficulty</span>
                      <Badge variant="outline" className="text-xs">
                        {session.difficulty < 0.4 ? 'Easy' : session.difficulty < 0.7 ? 'Medium' : 'Hard'}
                      </Badge>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {session.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documents" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold text-white">Document Library</h3>
            <Button onClick={handleDocumentUpload} className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              <Upload className="w-4 h-4 mr-2" />
              Upload Document
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {learningData.documents.map((doc) => (
              <Card key={doc.id} className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="text-white text-lg flex items-center">
                    <FileText className="w-5 h-5 mr-2 text-blue-400" />
                    {doc.title}
                  </CardTitle>
                  <CardDescription className="text-purple-200">
                    {doc.type.toUpperCase()} • {doc.pages > 0 ? `${doc.pages} pages` : 'Digital'}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="text-purple-200 text-sm">{doc.summary}</p>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm">Progress</span>
                        <span className="text-white font-medium">{Math.round(doc.readingProgress * 100)}%</span>
                      </div>
                      <Progress value={doc.readingProgress * 100} className="h-2" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-purple-200 text-sm">Insights</span>
                      <Badge variant="secondary" className="text-xs">
                        {doc.extractedInsights} extracted
                      </Badge>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {doc.keyTopics.slice(0, 3).map((topic, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {topic}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Flashcards Tab */}
        <TabsContent value="flashcards" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader className="pb-3">
                <CardTitle className="text-purple-200 text-sm font-medium">Total Cards</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{learningData.flashcards.total}</div>
              </CardContent>
            </Card>
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader className="pb-3">
                <CardTitle className="text-purple-200 text-sm font-medium">Due for Review</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-400">{learningData.flashcards.dueForReview}</div>
              </CardContent>
            </Card>
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader className="pb-3">
                <CardTitle className="text-purple-200 text-sm font-medium">Mastered</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-400">{learningData.flashcards.mastered}</div>
              </CardContent>
            </Card>
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader className="pb-3">
                <CardTitle className="text-purple-200 text-sm font-medium">Accuracy</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {Math.round(learningData.flashcards.averageAccuracy * 100)}%
                </div>
              </CardContent>
            </Card>
          </div>
          <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Zap className="w-5 h-5 mr-2 text-yellow-400" />
                Next Review Session
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-medium">
                    {new Date(learningData.flashcards.nextReviewSession).toLocaleString()}
                  </p>
                  <p className="text-purple-200 text-sm">
                    {learningData.flashcards.dueForReview} cards ready for review
                  </p>
                </div>
                <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                  Start Review
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}