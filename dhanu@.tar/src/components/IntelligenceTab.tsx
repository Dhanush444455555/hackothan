'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  Brain, 
  Bot, 
  Sparkles, 
  TrendingUp, 
  Activity,
  Target,
  Lightbulb,
  MessageSquare,
  RefreshCw
} from 'lucide-react'

interface PersonalIntelligence {
  cognitiveStyle: {
    primary: string;
    secondary: string;
    description: string;
    traits: string[];
  };
  decisionMaking: {
    style: string;
    riskTolerance: number;
    confidence: number;
    factors: string[];
  };
  behavioralPatterns: {
    peakProductivity: string;
    learningPreference: string;
    socialEnergy: string;
    workStyle: string;
    motivation: string;
  };
  emotionalIntelligence: {
    selfAwareness: number;
    empathy: number;
    adaptability: number;
    stressManagement: number;
  };
  strengths: string[];
  growthAreas: string[];
}

export default function IntelligenceTab() {
  const [intelligence, setIntelligence] = useState<PersonalIntelligence | null>(null)
  const [loading, setLoading] = useState(true)
  const [analyzing, setAnalyzing] = useState(false)

  useEffect(() => {
    loadIntelligence()
  }, [])

  const loadIntelligence = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/intelligence')
      if (!response.ok) {
        throw new Error('Failed to fetch intelligence data')
      }
      const data = await response.json()
      setIntelligence(data)
    } catch (error) {
      console.error('Error loading intelligence data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAnalyze = async () => {
    setAnalyzing(true)
    try {
      const response = await fetch('/api/intelligence', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'analyze',
          data: {
            recentActivities: ['work', 'learning', 'exercise'],
            mood: 'focused',
            energy: 85,
            sleep: 7.5
          }
        })
      })

      if (!response.ok) {
        throw new Error('Failed to analyze')
      }

      const result = await response.json()
      console.log('Analysis result:', result)
      // You could update the UI with new insights here
    } catch (error) {
      console.error('Error analyzing:', error)
    } finally {
      setAnalyzing(false)
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white">Loading Intelligence Data...</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-purple-800/30 rounded w-3/4"></div>
                  <div className="h-4 bg-purple-800/30 rounded w-1/2"></div>
                  <div className="h-4 bg-purple-800/30 rounded w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  if (!intelligence) return null

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Intelligence Analysis */}
        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Brain className="w-5 h-5 mr-2 text-purple-400" />
              Personal Intelligence Analysis
            </CardTitle>
            <CardDescription className="text-purple-200">
              Deep insights into your patterns and behaviors
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Cognitive Style */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-purple-800/20 border border-purple-700/30">
                  <h4 className="text-white font-medium mb-2">Cognitive Style</h4>
                  <p className="text-purple-200 text-sm mb-2">{intelligence.cognitiveStyle.description}</p>
                  <div className="flex flex-wrap gap-1">
                    {intelligence.cognitiveStyle.traits.map((trait, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {trait}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="p-4 rounded-lg bg-purple-800/20 border border-purple-700/30">
                  <h4 className="text-white font-medium mb-2">Decision Making</h4>
                  <p className="text-purple-200 text-sm mb-2">{intelligence.decisionMaking.style}</p>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-purple-200 text-xs">Risk Tolerance</span>
                      <span className="text-white font-medium">{Math.round(intelligence.decisionMaking.riskTolerance * 100)}%</span>
                    </div>
                    <Progress value={intelligence.decisionMaking.riskTolerance * 100} className="h-2" />
                  </div>
                </div>
              </div>

              {/* Behavioral Patterns */}
              <div className="p-4 rounded-lg bg-purple-800/20 border border-purple-700/30">
                <h4 className="text-white font-medium mb-3">Behavioral Patterns</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="flex items-center justify-between">
                    <span className="text-purple-200 text-sm">Peak productivity</span>
                    <span className="text-white font-medium">{intelligence.behavioralPatterns.peakProductivity}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-purple-200 text-sm">Learning preference</span>
                    <span className="text-white font-medium">{intelligence.behavioralPatterns.learningPreference}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-purple-200 text-sm">Social energy</span>
                    <span className="text-white font-medium">{intelligence.behavioralPatterns.socialEnergy}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-purple-200 text-sm">Work style</span>
                    <span className="text-white font-medium">{intelligence.behavioralPatterns.workStyle}</span>
                  </div>
                </div>
              </div>

              {/* Emotional Intelligence */}
              <div className="p-4 rounded-lg bg-purple-800/20 border border-purple-700/30">
                <h4 className="text-white font-medium mb-3">Emotional Intelligence</h4>
                <div className="space-y-3">
                  {Object.entries(intelligence.emotionalIntelligence).map(([key, value]) => (
                    <div key={key} className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm capitalize">
                          {key.replace(/([A-Z])/g, ' $1').trim()}
                        </span>
                        <span className="text-white font-medium">{Math.round(value * 100)}%</span>
                      </div>
                      <Progress value={value * 100} className="h-2" />
                    </div>
                  ))}
                </div>
              </div>

              {/* Strengths and Growth Areas */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-green-800/20 border border-green-700/30">
                  <h4 className="text-white font-medium mb-2 flex items-center">
                    <TrendingUp className="w-4 h-4 mr-2 text-green-400" />
                    Strengths
                  </h4>
                  <ul className="space-y-1">
                    {intelligence.strengths.map((strength, index) => (
                      <li key={index} className="text-green-200 text-sm flex items-center">
                        <div className="w-1 h-1 bg-green-400 rounded-full mr-2"></div>
                        {strength}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-4 rounded-lg bg-blue-800/20 border border-blue-700/30">
                  <h4 className="text-white font-medium mb-2 flex items-center">
                    <Target className="w-4 h-4 mr-2 text-blue-400" />
                    Growth Areas
                  </h4>
                  <ul className="space-y-1">
                    {intelligence.growthAreas.map((area, index) => (
                      <li key={index} className="text-blue-200 text-sm flex items-center">
                        <div className="w-1 h-1 bg-blue-400 rounded-full mr-2"></div>
                        {area}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AI Assistant */}
        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Bot className="w-5 h-5 mr-2 text-cyan-400" />
              AI Assistant
            </CardTitle>
            <CardDescription className="text-purple-200">
              Your personal AI companion
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* AI Insights */}
              <div className="p-3 rounded-lg bg-gradient-to-r from-cyan-800/20 to-blue-800/20 border border-cyan-700/30">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
                  <span className="text-cyan-200 text-sm font-medium">AI Insight</span>
                </div>
                <p className="text-white text-sm">
                  Your focus patterns suggest you're in a creative phase. Consider scheduling brainstorming sessions during your peak hours.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-gradient-to-r from-purple-800/20 to-pink-800/20 border border-purple-700/30">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                  <span className="text-purple-200 text-sm font-medium">Recommendation</span>
                </div>
                <p className="text-white text-sm">
                  Based on your mood patterns, a 15-minute meditation break could boost your afternoon productivity by 23%.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-gradient-to-r from-green-800/20 to-emerald-800/20 border border-green-700/30">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="text-green-200 text-sm font-medium">Opportunity</span>
                </div>
                <p className="text-white text-sm">
                  Your learning style indicates high retention for visual content. Try video tutorials for complex topics.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2">
                <Button 
                  onClick={handleAnalyze}
                  disabled={analyzing}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  {analyzing ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Deep Analysis
                    </>
                  )}
                </Button>
                <Button variant="outline" className="w-full border-purple-700/30 text-purple-200 hover:bg-purple-800/20">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Chat with AI
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}