'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Target, 
  Calendar, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  TrendingUp, 
  BarChart3,
  Zap,
  Plus,
  Play,
  Timer,
  Users,
  MapPin,
  Lightbulb,
  Activity,
  Brain,
  Settings
} from 'lucide-react'

interface ProductivityData {
  overview: {
    totalTasks: number;
    completedTasks: number;
    inProgressTasks: number;
    overdueTasks: number;
    completionRate: number;
    averageCompletionTime: number;
    productivityScore: number;
    focusTime: number;
    distractionCount: number;
    deepWorkSessions: number;
  };
  timeAnalysis: {
    totalWorkHours: number;
    productiveHours: number;
    meetingHours: number;
    breakHours: number;
    focusPercentage: number;
    peakProductivityHours: string[];
    energyLevels: Array<{
      hour: number;
      level: number;
    }>;
  };
  tasks: Array<{
    id: string;
    title: string;
    description: string;
    status: string;
    priority: string;
    category: string;
    estimatedTime: number;
    actualTime: number | null;
    dueDate: string;
    createdAt: string;
    tags: string[];
    context: string;
    subtasks: Array<{
      id: string;
      title: string;
      completed: boolean;
    }>;
  }>;
  calendarEvents: Array<{
    id: string;
    title: string;
    description: string;
    startTime: string;
    endTime: string;
    type: string;
    location: string;
    attendees: string[];
    status: string;
    priority: string;
  }>;
  workflows: Array<{
    id: string;
    name: string;
    description: string;
    steps: string[];
    automationLevel: number;
    timeSaved: number;
    frequency: string;
  }>;
  recommendations: Array<{
    type: string;
    title: string;
    description: string;
    impact: string;
    timeSaved: number;
    confidence: number;
  }>;
  insights: {
    productivityTrends: {
      last7Days: number[];
      average: number;
      improvement: number;
    };
    focusPatterns: {
      bestFocusTime: string;
      averageFocusSession: number;
      distractionFrequency: number;
      recoveryTime: number;
    };
    taskAnalysis: {
      mostProductiveCategory: string;
      averageTaskCompletionTime: number;
      overdueRate: number;
      completionByPriority: {
        high: number;
        medium: number;
        low: number;
      };
    };
  };
}

export default function ProductivityTab() {
  const [productivityData, setProductivityData] = useState<ProductivityData | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')

  useEffect(() => {
    loadProductivityData()
  }, [])

  const loadProductivityData = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/productivity')
      if (!response.ok) {
        throw new Error('Failed to fetch productivity data')
      }
      const data = await response.json()
      setProductivityData(data)
    } catch (error) {
      console.error('Error loading productivity data:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-purple-800/30 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="h-32 bg-purple-800/30 rounded"></div>
            <div className="h-32 bg-purple-800/30 rounded"></div>
            <div className="h-32 bg-purple-800/30 rounded"></div>
            <div className="h-32 bg-purple-800/30 rounded"></div>
          </div>
        </div>
      </div>
    )
  }

  if (!productivityData) return null

  return (
    <div className="space-y-6">
      {/* Productivity Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
              <Target className="w-4 h-4 mr-2" />
              Tasks Completed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">{productivityData.overview.completedTasks}</div>
            <p className="text-purple-200 text-xs mt-1">
              {Math.round(productivityData.overview.completionRate * 100)}% completion rate
            </p>
          </CardContent>
        </Card>

        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
              <Clock className="w-4 h-4 mr-2" />
              Focus Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-400">{productivityData.overview.focusTime}h</div>
            <p className="text-purple-200 text-xs mt-1">
              {productivityData.overview.deepWorkSessions} deep work sessions
            </p>
          </CardContent>
        </Card>

        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
              <Activity className="w-4 h-4 mr-2" />
              Productivity Score
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-400">{productivityData.overview.productivityScore}</div>
            <Progress value={productivityData.overview.productivityScore} className="mt-2 h-2" />
          </CardContent>
        </Card>

        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
              <Timer className="w-4 h-4 mr-2" />
              Avg Completion
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-400">{productivityData.overview.averageCompletionTime}d</div>
            <p className="text-purple-200 text-xs mt-1">Days per task</p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5 bg-black/30 border border-purple-700/30">
          <TabsTrigger value="overview" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Overview
          </TabsTrigger>
          <TabsTrigger value="tasks" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Tasks
          </TabsTrigger>
          <TabsTrigger value="calendar" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Calendar
          </TabsTrigger>
          <TabsTrigger value="workflows" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Workflows
          </TabsTrigger>
          <TabsTrigger value="insights" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Insights
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Time Analysis */}
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Clock className="w-5 h-5 mr-2 text-blue-400" />
                  Time Analysis
                </CardTitle>
                <CardDescription className="text-purple-200">
                  How you spend your workday
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 rounded-lg bg-green-800/20 border border-green-700/30">
                      <div className="flex items-center space-x-2 mb-1">
                        <TrendingUp className="w-4 h-4 text-green-400" />
                        <span className="text-green-200 text-sm font-medium">Productive</span>
                      </div>
                      <p className="text-white font-lg">{productivityData.timeAnalysis.productiveHours}h</p>
                    </div>
                    <div className="p-3 rounded-lg bg-red-800/20 border border-red-700/30">
                      <div className="flex items-center space-x-2 mb-1">
                        <Users className="w-4 h-4 text-red-400" />
                        <span className="text-red-200 text-sm font-medium">Meetings</span>
                      </div>
                      <p className="text-white font-lg">{productivityData.timeAnalysis.meetingHours}h</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-purple-200 text-sm">Focus Percentage</span>
                      <span className="text-white font-medium">{Math.round(productivityData.timeAnalysis.focusPercentage * 100)}%</span>
                    </div>
                    <Progress value={productivityData.timeAnalysis.focusPercentage * 100} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-white font-medium">Peak Productivity Hours</h4>
                    {productivityData.timeAnalysis.peakProductivityHours.map((hour, index) => (
                      <Badge key={index} variant="secondary" className="mr-2">
                        {hour}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Energy Levels */}
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Activity className="w-5 h-5 mr-2 text-purple-400" />
                  Energy Levels
                </CardTitle>
                <CardDescription className="text-purple-200">
                  Your daily energy pattern
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    {productivityData.timeAnalysis.energyLevels.map((level) => (
                      <div key={level.hour} className="flex items-center space-x-3">
                        <span className="text-purple-200 text-sm w-12">
                          {level.hour}:00
                        </span>
                        <div className="flex-1">
                          <Progress value={level.level * 100} className="h-2" />
                        </div>
                        <span className="text-white text-sm w-12">
                          {Math.round(level.level * 100)}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Tasks Tab */}
        <TabsContent value="tasks" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold text-white">Task Management</h3>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Task
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {productivityData.tasks.map((task) => (
              <Card key={task.id} className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="text-white text-lg flex items-center justify-between">
                    {task.title}
                    <Badge variant={task.priority === 'high' ? 'destructive' : task.priority === 'medium' ? 'default' : 'secondary'} className="text-xs">
                      {task.priority}
                    </Badge>
                  </CardTitle>
                  <CardDescription className="text-purple-200">
                    {task.category} • {task.context}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="text-purple-200 text-sm">{task.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-purple-200 text-sm">Status</span>
                      <Badge variant="outline" className="text-xs">
                        {task.status.replace('_', ' ')}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-purple-200 text-sm">Time</span>
                      <span className="text-white font-medium">
                        {task.actualTime ? formatTime(task.actualTime) : formatTime(task.estimatedTime)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-purple-200 text-sm">Due</span>
                      <span className="text-white font-medium">
                        {new Date(task.dueDate).toLocaleDateString()}
                      </span>
                    </div>
                    {task.subtasks.length > 0 && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-purple-200 text-sm">Subtasks</span>
                          <span className="text-white font-medium">
                            {task.subtasks.filter(st => st.completed).length}/{task.subtasks.length}
                          </span>
                        </div>
                        <Progress 
                          value={(task.subtasks.filter(st => st.completed).length / task.subtasks.length) * 100} 
                          className="h-1" 
                        />
                      </div>
                    )}
                    <div className="flex flex-wrap gap-1">
                      {task.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Calendar Tab */}
        <TabsContent value="calendar" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold text-white">Calendar Events</h3>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              <Calendar className="w-4 h-4 mr-2" />
              Schedule Event
            </Button>
          </div>
          <div className="space-y-4">
            {productivityData.calendarEvents.map((event) => (
              <Card key={event.id} className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        event.type === 'meeting' ? 'bg-red-800/20' : 
                        event.type === 'work' ? 'bg-blue-800/20' : 'bg-green-800/20'
                      }`}>
                        {event.type === 'meeting' ? (
                          <Users className="w-5 h-5 text-red-400" />
                        ) : event.type === 'work' ? (
                          <Target className="w-5 h-5 text-blue-400" />
                        ) : (
                          <Play className="w-5 h-5 text-green-400" />
                        )}
                      </div>
                      <div>
                        <p className="text-white font-medium">{event.title}</p>
                        <p className="text-purple-200 text-sm">
                          {event.description}
                        </p>
                        <div className="flex items-center space-x-4 mt-1">
                          <div className="flex items-center space-x-1">
                            <Clock className="w-3 h-3 text-purple-400" />
                            <span className="text-purple-200 text-sm">
                              {new Date(event.startTime).toLocaleTimeString()} - {new Date(event.endTime).toLocaleTimeString()}
                            </span>
                          </div>
                          {event.location && (
                            <div className="flex items-center space-x-1">
                              <MapPin className="w-3 h-3 text-purple-400" />
                              <span className="text-purple-200 text-sm">{event.location}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant={event.priority === 'high' ? 'destructive' : event.priority === 'medium' ? 'default' : 'secondary'} className="text-xs">
                        {event.priority}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Workflows Tab */}
        <TabsContent value="workflows" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold text-white">Automated Workflows</h3>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              <Settings className="w-4 h-4 mr-2" />
              Create Workflow
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {productivityData.workflows.map((workflow) => (
              <Card key={workflow.id} className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader>
                  <CardTitle className="text-white text-lg">{workflow.name}</CardTitle>
                  <CardDescription className="text-purple-200">
                    {workflow.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <h4 className="text-white font-medium">Steps</h4>
                      <ul className="space-y-1">
                        {workflow.steps.map((step, index) => (
                          <li key={index} className="text-purple-200 text-sm flex items-center">
                            <div className="w-4 h-4 rounded-full bg-purple-600 text-white text-xs flex items-center justify-center mr-2">
                              {index + 1}
                            </div>
                            {step}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 rounded-lg bg-purple-800/20 border border-purple-700/30">
                        <div className="flex items-center space-x-2 mb-1">
                          <Zap className="w-4 h-4 text-yellow-400" />
                          <span className="text-yellow-200 text-sm font-medium">Automation</span>
                        </div>
                        <p className="text-white font-lg">{Math.round(workflow.automationLevel * 100)}%</p>
                      </div>
                      <div className="p-3 rounded-lg bg-green-800/20 border border-green-700/30">
                        <div className="flex items-center space-x-2 mb-1">
                          <Clock className="w-4 h-4 text-green-400" />
                          <span className="text-green-200 text-sm font-medium">Time Saved</span>
                        </div>
                        <p className="text-white font-lg">{workflow.timeSaved}m</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="w-full justify-center">
                      {workflow.frequency}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Insights Tab */}
        <TabsContent value="insights" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Productivity Trends */}
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
                  Productivity Trends
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-400">
                      +{Math.round(productivityData.insights.productivityTrends.improvement * 100)}%
                    </div>
                    <p className="text-purple-200 text-sm">7-day improvement</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-purple-200 text-sm">Average Score</span>
                      <span className="text-white font-medium">
                        {Math.round(productivityData.insights.productivityTrends.average * 100)}%
                      </span>
                    </div>
                    <Progress value={productivityData.insights.productivityTrends.average * 100} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* AI Recommendations */}
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Lightbulb className="w-5 h-5 mr-2 text-yellow-400" />
                  AI Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {productivityData.recommendations.map((rec, index) => (
                    <div key={index} className="p-3 rounded-lg bg-purple-800/20 border border-purple-700/30">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-white font-medium">{rec.title}</span>
                        <Badge variant={rec.impact === 'high' ? 'destructive' : rec.impact === 'medium' ? 'default' : 'secondary'} className="text-xs">
                          {rec.impact}
                        </Badge>
                      </div>
                      <p className="text-purple-200 text-sm mb-2">{rec.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-green-400 text-sm">
                          Time saved: {rec.timeSaved}m
                        </span>
                        <span className="text-purple-200 text-sm">
                          {Math.round(rec.confidence * 100)}% confidence
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Focus Patterns */}
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-purple-400" />
                  Focus Patterns
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 rounded-lg bg-purple-800/20 border border-purple-700/30">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-white font-medium">Best Focus Time</span>
                      <Timer className="w-4 h-4 text-purple-400" />
                    </div>
                    <p className="text-purple-200 text-sm">{productivityData.insights.focusPatterns.bestFocusTime}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 rounded-lg bg-blue-800/20 border border-blue-700/30">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-blue-200 text-sm font-medium">Avg Session</span>
                      </div>
                      <p className="text-white font-lg">{productivityData.insights.focusPatterns.averageFocusSession}m</p>
                    </div>
                    <div className="p-3 rounded-lg bg-red-800/20 border border-red-700/30">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-red-200 text-sm font-medium">Distractions</span>
                      </div>
                      <p className="text-white font-lg">{productivityData.insights.focusPatterns.distractionFrequency}/h</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Task Analysis */}
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2 text-blue-400" />
                  Task Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 rounded-lg bg-purple-800/20 border border-purple-700/30">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-white font-medium">Most Productive Category</span>
                      <Target className="w-4 h-4 text-purple-400" />
                    </div>
                    <p className="text-purple-200 text-sm">{productivityData.insights.taskAnalysis.mostProductiveCategory}</p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-white font-medium">Completion by Priority</h4>
                    {Object.entries(productivityData.insights.taskAnalysis.completionByPriority).map(([priority, rate]) => (
                      <div key={priority} className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-purple-200 text-sm capitalize">{priority}</span>
                          <span className="text-white font-medium">{Math.round(rate * 100)}%</span>
                        </div>
                        <Progress value={rate * 100} className="h-2" />
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}