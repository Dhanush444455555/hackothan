'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Target, 
  AlertCircle, 
  CheckCircle,
  PiggyBank,
  CreditCard,
  Receipt,
  Lightbulb,
  BarChart3,
  Calendar,
  Shield,
  Zap,
  Plus
} from 'lucide-react'

interface FinancialData {
  overview: {
    totalIncome: number;
    totalExpenses: number;
    netSavings: number;
    savingsRate: number;
    monthlyBudget: number;
    currentMonthSpent: number;
    budgetRemaining: number;
    emergencyFund: number;
    emergencyFundTarget: number;
    investments: number;
    investmentReturns: number;
  };
  spendingAnalysis: {
    categories: Array<{
      name: string;
      amount: number;
      percentage: number;
      budget: number;
      status: string;
    }>;
    trends: {
      last3Months: number[];
      averageMonthly: number;
      yearOverYearChange: number;
      projectedAnnual: number;
    };
  };
  recentTransactions: Array<{
    id: string;
    description: string;
    amount: number;
    category: string;
    date: string;
    type: string;
    recurring: boolean;
    merchant: string;
    paymentMethod: string;
  }>;
  goals: Array<{
    id: string;
    title: string;
    target: number;
    current: number;
    progress: number;
    monthlyContribution: number;
    targetDate: string;
    priority: string;
    category: string;
  }>;
  predictions: Array<{
    type: string;
    title: string;
    probability: number;
    estimatedCost?: number;
    estimatedAmount?: number;
    timeframe: string;
    confidence: number;
  }>;
  recommendations: Array<{
    type: string;
    title: string;
    description: string;
    potentialSavings?: number;
    potentialReturn?: number;
    priority: string;
  }>;
  insights: {
    financialHealthScore: number;
    strengths: string[];
    improvements: string[];
    riskFactors: string[];
    opportunities: string[];
  };
}

export default function FinanceTab() {
  const [financialData, setFinancialData] = useState<FinancialData | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')

  useEffect(() => {
    loadFinancialData()
  }, [])

  const loadFinancialData = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/finance')
      if (!response.ok) {
        throw new Error('Failed to fetch financial data')
      }
      const data = await response.json()
      setFinancialData(data)
    } catch (error) {
      console.error('Error loading financial data:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount)
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-purple-800/30 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="h-32 bg-purple-800/30 rounded"></div>
            <div className="h-32 bg-purple-800/30 rounded"></div>
            <div className="h-32 bg-purple-800/30 rounded"></div>
            <div className="h-32 bg-purple-800/30 rounded"></div>
          </div>
        </div>
      </div>
    )
  }

  if (!financialData) return null

  return (
    <div className="space-y-6">
      {/* Financial Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
              <TrendingUp className="w-4 h-4 mr-2" />
              Total Income
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">{formatCurrency(financialData.overview.totalIncome)}</div>
            <p className="text-purple-200 text-xs mt-1">Annual</p>
          </CardContent>
        </Card>

        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
              <TrendingDown className="w-4 h-4 mr-2" />
              Total Expenses
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-400">{formatCurrency(financialData.overview.totalExpenses)}</div>
            <p className="text-purple-200 text-xs mt-1">Annual</p>
          </CardContent>
        </Card>

        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
              <PiggyBank className="w-4 h-4 mr-2" />
              Net Savings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-400">{formatCurrency(financialData.overview.netSavings)}</div>
            <p className="text-purple-200 text-xs mt-1">
              {Math.round(financialData.overview.savingsRate * 100)}% savings rate
            </p>
          </CardContent>
        </Card>

        <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
              <Shield className="w-4 h-4 mr-2" />
              Emergency Fund
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-400">{formatCurrency(financialData.overview.emergencyFund)}</div>
            <Progress value={(financialData.overview.emergencyFund / financialData.overview.emergencyFundTarget) * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5 bg-black/30 border border-purple-700/30">
          <TabsTrigger value="overview" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Overview
          </TabsTrigger>
          <TabsTrigger value="transactions" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Transactions
          </TabsTrigger>
          <TabsTrigger value="goals" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Goals
          </TabsTrigger>
          <TabsTrigger value="predictions" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Predictions
          </TabsTrigger>
          <TabsTrigger value="insights" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Insights
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Spending by Category */}
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2 text-purple-400" />
                  Spending by Category
                </CardTitle>
                <CardDescription className="text-purple-200">
                  Monthly budget breakdown
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {financialData.spendingAnalysis.categories.map((category) => (
                    <div key={category.name} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-white font-medium">{category.name}</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-purple-200 text-sm">
                            {formatCurrency(category.amount)}
                          </span>
                          {category.status === 'over_budget' ? (
                            <AlertCircle className="w-4 h-4 text-red-400" />
                          ) : (
                            <CheckCircle className="w-4 h-4 text-green-400" />
                          )}
                        </div>
                      </div>
                      <div className="space-y-1">
                        <Progress 
                          value={(category.amount / category.budget) * 100} 
                          className="h-2"
                        />
                        <div className="flex items-center justify-between">
                          <span className="text-purple-200 text-xs">
                            {Math.round(category.percentage * 100)}% of budget
                          </span>
                          <span className="text-purple-200 text-xs">
                            {formatCurrency(category.budget)} budget
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Budget Status */}
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <CreditCard className="w-5 h-5 mr-2 text-blue-400" />
                  Budget Status
                </CardTitle>
                <CardDescription className="text-purple-200">
                  Current month budget performance
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 rounded-lg bg-purple-800/20 border border-purple-700/30">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-white font-medium">Monthly Budget</span>
                      <span className="text-purple-200 text-sm">
                        {formatCurrency(financialData.overview.monthlyBudget)}
                      </span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm">Spent</span>
                        <span className="text-red-400 font-medium">
                          {formatCurrency(financialData.overview.currentMonthSpent)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm">Remaining</span>
                        <span className="text-green-400 font-medium">
                          {formatCurrency(financialData.overview.budgetRemaining)}
                        </span>
                      </div>
                    </div>
                    <Progress 
                      value={(financialData.overview.currentMonthSpent / financialData.overview.monthlyBudget) * 100} 
                      className="mt-3 h-2" 
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 rounded-lg bg-green-800/20 border border-green-700/30">
                      <div className="flex items-center space-x-2 mb-1">
                        <TrendingUp className="w-4 h-4 text-green-400" />
                        <span className="text-green-200 text-sm font-medium">Investments</span>
                      </div>
                      <p className="text-white font-lg">{formatCurrency(financialData.overview.investments)}</p>
                      <p className="text-green-200 text-xs">
                        +{Math.round(financialData.overview.investmentReturns * 100)}% returns
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-800/20 border border-blue-700/30">
                      <div className="flex items-center space-x-2 mb-1">
                        <Shield className="w-4 h-4 text-blue-400" />
                        <span className="text-blue-200 text-sm font-medium">Emergency Fund</span>
                      </div>
                      <p className="text-white font-lg">{formatCurrency(financialData.overview.emergencyFund)}</p>
                      <p className="text-blue-200 text-xs">
                        {Math.round((financialData.overview.emergencyFund / financialData.overview.emergencyFundTarget) * 100)}% of target
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Transactions Tab */}
        <TabsContent value="transactions" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold text-white">Recent Transactions</h3>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Transaction
            </Button>
          </div>
          <div className="space-y-3">
            {financialData.recentTransactions.map((transaction) => (
              <Card key={transaction.id} className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        transaction.type === 'income' ? 'bg-green-800/20' : 'bg-red-800/20'
                      }`}>
                        {transaction.type === 'income' ? (
                          <TrendingUp className="w-5 h-5 text-green-400" />
                        ) : (
                          <TrendingDown className="w-5 h-5 text-red-400" />
                        )}
                      </div>
                      <div>
                        <p className="text-white font-medium">{transaction.description}</p>
                        <p className="text-purple-200 text-sm">
                          {transaction.merchant} • {transaction.paymentMethod}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold ${
                        transaction.type === 'income' ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {transaction.type === 'income' ? '+' : ''}{formatCurrency(transaction.amount)}
                      </p>
                      <p className="text-purple-200 text-sm">
                        {new Date(transaction.date).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Goals Tab */}
        <TabsContent value="goals" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold text-white">Financial Goals</h3>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              <Target className="w-4 h-4 mr-2" />
              Set New Goal
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {financialData.goals.map((goal) => (
              <Card key={goal.id} className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="text-white text-lg">{goal.title}</CardTitle>
                  <CardDescription className="text-purple-200">
                    Target: {new Date(goal.targetDate).toLocaleDateString()}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm">Progress</span>
                        <span className="text-white font-medium">{Math.round(goal.progress * 100)}%</span>
                      </div>
                      <Progress value={goal.progress * 100} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm">Current</span>
                        <span className="text-white font-medium">{formatCurrency(goal.current)}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm">Target</span>
                        <span className="text-white font-medium">{formatCurrency(goal.target)}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm">Monthly</span>
                        <span className="text-white font-medium">{formatCurrency(goal.monthlyContribution)}</span>
                      </div>
                    </div>
                    <Badge variant={goal.priority === 'high' ? 'destructive' : goal.priority === 'medium' ? 'default' : 'secondary'} className="w-full justify-center">
                      {goal.priority} priority
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Predictions Tab */}
        <TabsContent value="predictions" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold text-white">AI Predictions</h3>
            <Button variant="outline" className="border-purple-700/30 text-purple-200 hover:bg-purple-800/20">
              <Zap className="w-4 h-4 mr-2" />
              Generate New Predictions
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {financialData.predictions.map((prediction, index) => (
              <Card key={index} className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="text-white text-lg flex items-center">
                    <Zap className="w-5 h-5 mr-2 text-yellow-400" />
                    {prediction.title}
                  </CardTitle>
                  <CardDescription className="text-purple-200">
                    {prediction.timeframe}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-purple-200 text-sm">Probability</span>
                      <span className="text-white font-medium">{Math.round(prediction.probability * 100)}%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-purple-200 text-sm">Confidence</span>
                      <span className="text-white font-medium">{Math.round(prediction.confidence * 100)}%</span>
                    </div>
                    {prediction.estimatedCost && (
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm">Est. Cost</span>
                        <span className="text-white font-medium">{formatCurrency(prediction.estimatedCost)}</span>
                      </div>
                    )}
                    {prediction.estimatedAmount && (
                      <div className="flex items-center justify-between">
                        <span className="text-purple-200 text-sm">Est. Amount</span>
                        <span className="text-white font-medium">{formatCurrency(prediction.estimatedAmount)}</span>
                      </div>
                    )}
                    <Badge variant="outline" className="w-full justify-center">
                      {prediction.type}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Insights Tab */}
        <TabsContent value="insights" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Financial Health Score */}
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2 text-purple-400" />
                  Financial Health Score
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-white mb-2">
                      {financialData.insights.financialHealthScore}/100
                    </div>
                    <Progress value={financialData.insights.financialHealthScore} className="h-3" />
                    <p className="text-purple-200 text-sm mt-2">
                      {financialData.insights.financialHealthScore >= 80 ? 'Excellent' :
                       financialData.insights.financialHealthScore >= 60 ? 'Good' :
                       financialData.insights.financialHealthScore >= 40 ? 'Fair' : 'Needs Improvement'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* AI Recommendations */}
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Lightbulb className="w-5 h-5 mr-2 text-yellow-400" />
                  AI Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {financialData.recommendations.map((rec, index) => (
                    <div key={index} className="p-3 rounded-lg bg-purple-800/20 border border-purple-700/30">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-white font-medium">{rec.title}</span>
                        <Badge variant={rec.priority === 'high' ? 'destructive' : rec.priority === 'medium' ? 'default' : 'secondary'} className="text-xs">
                          {rec.priority}
                        </Badge>
                      </div>
                      <p className="text-purple-200 text-sm mb-2">{rec.description}</p>
                      {rec.potentialSavings && (
                        <p className="text-green-400 text-sm">
                          Potential savings: {formatCurrency(rec.potentialSavings)}
                        </p>
                      )}
                      {rec.potentialReturn && (
                        <p className="text-blue-400 text-sm">
                          Potential return: {Math.round(rec.potentialReturn * 100)}%
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Strengths and Improvements */}
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <CheckCircle className="w-5 h-5 mr-2 text-green-400" />
                  Strengths
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {financialData.insights.strengths.map((strength, index) => (
                    <li key={index} className="text-green-200 text-sm flex items-center">
                      <CheckCircle className="w-4 h-4 mr-2 text-green-400" />
                      {strength}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <AlertCircle className="w-5 h-5 mr-2 text-orange-400" />
                  Areas for Improvement
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {financialData.insights.improvements.map((improvement, index) => (
                    <li key={index} className="text-orange-200 text-sm flex items-center">
                      <AlertCircle className="w-4 h-4 mr-2 text-orange-400" />
                      {improvement}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}