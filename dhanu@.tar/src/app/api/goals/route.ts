import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    // Mock goals data
    const goals = [
      {
        id: "1",
        title: "Learn Advanced AI",
        description: "Master advanced artificial intelligence concepts and applications",
        category: "learning",
        priority: "high",
        status: "active",
        progress: 0.65,
        targetDate: "2024-06-30",
        createdAt: "2024-01-01",
        milestones: [
          {
            id: "1-1",
            title: "Complete ML fundamentals",
            completed: true,
            completedAt: "2024-01-15",
            dueDate: "2024-01-31"
          },
          {
            id: "1-2",
            title: "Build first neural network",
            completed: true,
            completedAt: "2024-02-28",
            dueDate: "2024-02-28"
          },
          {
            id: "1-3",
            title: "Complete advanced course",
            completed: false,
            dueDate: "2024-04-30"
          },
          {
            id: "1-4",
            title: "Build AI project portfolio",
            completed: false,
            dueDate: "2024-06-30"
          }
        ],
        metrics: {
          hoursInvested: 120,
          coursesCompleted: 3,
          projectsBuilt: 2,
          skillsAcquired: ["Neural Networks", "Deep Learning", "NLP"]
        }
      },
      {
        id: "2",
        title: "Financial Independence",
        description: "Achieve financial freedom through smart investing and saving",
        category: "financial",
        priority: "high",
        status: "active",
        progress: 0.42,
        targetDate: "2025-12-31",
        createdAt: "2024-01-01",
        milestones: [
          {
            id: "2-1",
            title: "Build emergency fund",
            completed: true,
            completedAt: "2024-02-15",
            dueDate: "2024-03-31"
          },
          {
            id: "2-2",
            title: "Start investment portfolio",
            completed: true,
            completedAt: "2024-03-01",
            dueDate: "2024-03-31"
          },
          {
            id: "2-3",
            title: "Reach 25% of target amount",
            completed: false,
            dueDate: "2024-12-31"
          },
          {
            id: "2-4",
            title: "Achieve 50% of target amount",
            completed: false,
            dueDate: "2025-06-30"
          }
        ],
        metrics: {
          totalSaved: 15000,
          totalInvested: 8000,
          monthlySavingsRate: 0.30,
          investmentReturns: 0.12
        }
      },
      {
        id: "3",
        title: "Health Optimization",
        description: "Achieve optimal physical and mental health",
        category: "wellness",
        priority: "medium",
        status: "active",
        progress: 0.78,
        targetDate: "2024-12-31",
        createdAt: "2024-01-01",
        milestones: [
          {
            id: "3-1",
            title: "Establish workout routine",
            completed: true,
            completedAt: "2024-01-31",
            dueDate: "2024-02-28"
          },
          {
            id: "3-2",
            title: "Reach target weight",
            completed: true,
            completedAt: "2024-03-15",
            dueDate: "2024-04-30"
          },
          {
            id: "3-3",
            title: "Complete fitness assessment",
            completed: false,
            dueDate: "2024-06-30"
          },
          {
            id: "3-4",
            title: "Maintain consistency for 6 months",
            completed: false,
            dueDate: "2024-12-31"
          }
        ],
        metrics: {
          weightLoss: 15,
          workoutDaysPerWeek: 4,
          restingHeartRate: 62,
          energyLevel: 8
        }
      },
      {
        id: "4",
        title: "Build Professional Network",
        description: "Expand professional connections and opportunities",
        category: "career",
        priority: "medium",
        status: "active",
        progress: 0.35,
        targetDate: "2024-09-30",
        createdAt: "2024-01-01",
        milestones: [
          {
            id: "4-1",
            title: "Join professional associations",
            completed: true,
            completedAt: "2024-02-01",
            dueDate: "2024-02-28"
          },
          {
            id: "4-2",
            title: "Attend 5 networking events",
            completed: false,
            dueDate: "2024-06-30"
          },
          {
            id: "4-3",
            title: "Connect with 50 professionals",
            completed: false,
            dueDate: "2024-09-30"
          }
        ],
        metrics: {
 linkedinConnections: 150,
          eventsAttended: 2,
          mentorshipRelationships: 1,
          collaborationsInitiated: 3
        }
      }
    ]

    return NextResponse.json(goals)
  } catch (error) {
    console.error('Goals API error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch goals' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { action, goalId, data } = await request.json()

    if (action === 'update-progress') {
      // Update goal progress
      return NextResponse.json({
        success: true,
        message: "Goal progress updated",
        progress: data.progress,
        updatedAt: new Date().toISOString()
      })
    }

    if (action === 'complete-milestone') {
      // Complete a milestone
      return NextResponse.json({
        success: true,
        message: "Milestone completed",
        completedAt: new Date().toISOString(),
        newProgress: data.newProgress
      })
    }

    if (action === 'create') {
      // Create new goal
      const newGoal = {
        id: Date.now().toString(),
        ...data,
        progress: 0.0,
        status: "active",
        createdAt: new Date().toISOString(),
        milestones: []
      }

      return NextResponse.json({
        success: true,
        goal: newGoal
      })
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
  } catch (error) {
    console.error('Goals POST error:', error)
    return NextResponse.json(
      { error: 'Failed to process goal request' },
      { status: 500 }
    )
  }
}