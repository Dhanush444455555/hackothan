import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    // Mock habits data
    const habits = [
      {
        id: "1",
        name: "Morning Meditation",
        category: "wellness",
        frequency: "daily",
        strength: 0.85,
        streak: 12,
        lastCompleted: new Date().toISOString(),
        targetTime: "07:00",
        duration: 15,
        description: "Start the day with mindfulness and clarity",
        benefits: ["Reduced stress", "Better focus", "Emotional balance"],
        milestones: [
          { days: 7, achieved: true, title: "One week streak" },
          { days: 21, achieved: false, title: "Three week streak" },
          { days: 66, achieved: false, title: "Two month streak" }
        ]
      },
      {
        id: "2",
        name: "Reading",
        category: "learning",
        frequency: "daily",
        strength: 0.72,
        streak: 8,
        lastCompleted: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        targetTime: "20:00",
        duration: 30,
        description: "Expand knowledge and vocabulary",
        benefits: ["Knowledge growth", "Vocabulary expansion", "Cognitive stimulation"],
        milestones: [
          { days: 7, achieved: true, title: "One week streak" },
          { days: 21, achieved: false, title: "Three week streak" },
          { days: 66, achieved: false, title: "Two month streak" }
        ]
      },
      {
        id: "3",
        name: "Exercise",
        category: "health",
        frequency: "daily",
        strength: 0.68,
        streak: 5,
        lastCompleted: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        targetTime: "18:00",
        duration: 45,
        description: "Maintain physical health and energy",
        benefits: ["Physical fitness", "Energy boost", "Stress relief"],
        milestones: [
          { days: 7, achieved: false, title: "One week streak" },
          { days: 21, achieved: false, title: "Three week streak" },
          { days: 66, achieved: false, title: "Two month streak" }
        ]
      },
      {
        id: "4",
        name: "Journaling",
        category: "wellness",
        frequency: "daily",
        strength: 0.90,
        streak: 30,
        lastCompleted: new Date().toISOString(),
        targetTime: "21:00",
        duration: 10,
        description: "Reflect on thoughts and experiences",
        benefits: ["Self-awareness", "Emotional processing", "Goal clarity"],
        milestones: [
          { days: 7, achieved: true, title: "One week streak" },
          { days: 21, achieved: true, title: "Three week streak" },
          { days: 66, achieved: false, title: "Two month streak" }
        ]
      },
      {
        id: "5",
        name: "Learning New Skills",
        category: "learning",
        frequency: "weekly",
        strength: 0.78,
        streak: 4,
        lastCompleted: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        targetTime: "Saturday 14:00",
        duration: 120,
        description: "Dedicated time for skill development",
        benefits: ["Career growth", "Cognitive flexibility", "Personal development"],
        milestones: [
          { weeks: 4, achieved: true, title: "One month streak" },
          { weeks: 12, achieved: false, title: "Three month streak" },
          { weeks: 24, achieved: false, title: "Six month streak" }
        ]
      }
    ]

    return NextResponse.json(habits)
  } catch (error) {
    console.error('Habits API error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch habits' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { action, habitId, data } = await request.json()

    if (action === 'complete') {
      // Mark habit as completed
      return NextResponse.json({
        success: true,
        message: "Habit marked as completed",
        streak: data.streak + 1,
        strength: Math.min(1.0, data.strength + 0.05)
      })
    }

    if (action === 'create') {
      // Create new habit
      const newHabit = {
        id: Date.now().toString(),
        ...data,
        strength: 0.1,
        streak: 0,
        createdAt: new Date().toISOString()
      }

      return NextResponse.json({
        success: true,
        habit: newHabit
      })
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
  } catch (error) {
    console.error('Habits POST error:', error)
    return NextResponse.json(
      { error: 'Failed to process habit request' },
      { status: 500 }
    )
  }
}