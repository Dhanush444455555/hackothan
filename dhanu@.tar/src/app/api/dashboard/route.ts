import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    // For now, return mock data since we don't have real users yet
    // In a real implementation, you'd get the user ID from authentication
    const mockData = {
      user: {
        name: "Alex Chen",
        persona: "Creative Visionary",
        mood: "Focused",
        energy: 85
      },
      insights: {
        productivity: 78,
        learning: 92,
        financial: 65,
        wellness: 88
      },
      predictions: [
        {
          type: "productivity",
          title: "Peak focus window: 2-4 PM",
          confidence: 0.87,
          timeframe: "today"
        },
        {
          type: "learning",
          title: "Optimal study session: 45 minutes",
          confidence: 0.92,
          timeframe: "today"
        },
        {
          type: "financial",
          title: "Unexpected expense likely: $50-100",
          confidence: 0.73,
          timeframe: "week"
        }
      ],
      tasks: [
        {
          id: "1",
          title: "Complete project proposal",
          priority: "high",
          category: "work",
          dueDate: "2024-01-15"
        },
        {
          id: "2",
          title: "Review machine learning course",
          priority: "medium",
          category: "learning",
          dueDate: "2024-01-16"
        },
        {
          id: "3",
          title: "Meditation session",
          priority: "low",
          category: "wellness",
          dueDate: "2024-01-14"
        }
      ],
      habits: [
        {
          name: "Morning Meditation",
          streak: 12,
          strength: 0.85
        },
        {
          name: "Reading",
          streak: 8,
          strength: 0.72
        },
        {
          name: "Exercise",
          streak: 5,
          strength: 0.68
        }
      ],
      goals: [
        {
          title: "Learn Advanced AI",
          progress: 0.65,
          category: "learning"
        },
        {
          title: "Financial Independence",
          progress: 0.42,
          category: "financial"
        },
        {
          title: "Health Optimization",
          progress: 0.78,
          category: "wellness"
        }
      ]
    }

    return NextResponse.json(mockData)
  } catch (error) {
    console.error('Dashboard API error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch dashboard data' },
      { status: 500 }
    )
  }
}