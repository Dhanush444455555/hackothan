import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

export async function GET(request: NextRequest) {
  try {
    // Mock personal intelligence data
    const personalIntelligence = {
      cognitiveStyle: {
        primary: "Analytical",
        secondary: "Creative",
        description: "Balanced analytical thinking with creative problem-solving",
        traits: ["Pattern recognition", "Systematic approach", "Innovative thinking"]
      },
      decisionMaking: {
        style: "Data-driven with intuition",
        riskTolerance: 0.65,
        confidence: 0.78,
        factors: ["Logic", "Experience", "Intuition", "Values"]
      },
      behavioralPatterns: {
        peakProductivity: "2:00 PM - 4:00 PM",
        learningPreference: "Visual + Kinesthetic",
        socialEnergy: "Introverted recharge",
        workStyle: "Deep work sessions",
        motivation: "Intrinsic + Achievement oriented"
      },
      emotionalIntelligence: {
        selfAwareness: 0.82,
        empathy: 0.75,
        adaptability: 0.88,
        stressManagement: 0.70
      },
      strengths: [
        "Complex problem solving",
        "Creative thinking",
        "Pattern recognition",
        "Strategic planning"
      ],
      growthAreas: [
        "Public speaking",
        "Networking",
        "Delegation",
        "Work-life balance"
      ]
    }

    return NextResponse.json(personalIntelligence)
  } catch (error) {
    console.error('Personal Intelligence API error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch personal intelligence data' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { action, data } = await request.json()

    if (action === 'analyze') {
      // Use ZAI to analyze user behavior patterns
      const zai = await ZAI.create()
      
      const analysis = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert in personal psychology and behavioral analysis. Analyze the user data and provide insights about their cognitive patterns, decision-making style, and behavioral tendencies.'
          },
          {
            role: 'user',
            content: `Analyze this user data and provide personal intelligence insights: ${JSON.stringify(data)}`
          }
        ],
        temperature: 0.7,
        max_tokens: 1000
      })

      const insights = analysis.choices[0]?.message?.content || 'Analysis complete'

      return NextResponse.json({
        insights,
        timestamp: new Date().toISOString(),
        confidence: 0.85
      })
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
  } catch (error) {
    console.error('Personal Intelligence POST error:', error)
    return NextResponse.json(
      { error: 'Failed to process personal intelligence request' },
      { status: 500 }
    )
  }
}