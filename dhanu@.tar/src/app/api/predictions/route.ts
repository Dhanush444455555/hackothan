import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

export async function GET(request: NextRequest) {
  try {
    // Mock predictive data
    const predictions = [
      {
        id: "1",
        type: "productivity",
        title: "Peak focus window: 2-4 PM",
        description: "Your cognitive patterns indicate optimal focus during afternoon hours",
        confidence: 0.87,
        timeframe: "today",
        impact: "high",
        actionable: true,
        suggestions: [
          "Schedule important tasks between 2-4 PM",
          "Avoid meetings during this time",
          "Prepare materials in advance"
        ]
      },
      {
        id: "2",
        type: "learning",
        title: "Optimal study session: 45 minutes",
        description: "Your attention span peaks at 45 minutes for new information",
        confidence: 0.92,
        timeframe: "today",
        impact: "medium",
        actionable: true,
        suggestions: [
          "Break learning into 45-minute sessions",
          "Take 15-minute breaks between sessions",
          "Review material after breaks"
        ]
      },
      {
        id: "3",
        type: "financial",
        title: "Unexpected expense likely: $50-100",
        description: "Based on your spending patterns, prepare for unexpected costs",
        confidence: 0.73,
        timeframe: "week",
        impact: "medium",
        actionable: true,
        suggestions: [
          "Set aside emergency funds",
          "Review discretionary spending",
          "Consider insurance options"
        ]
      },
      {
        id: "4",
        type: "health",
        title: "Sleep quality may decline",
        description: "Stress levels indicate potential sleep disruption",
        confidence: 0.68,
        timeframe: "week",
        impact: "high",
        actionable: true,
        suggestions: [
          "Maintain consistent sleep schedule",
          "Practice relaxation techniques",
          "Limit screen time before bed"
        ]
      },
      {
        id: "5",
        type: "social",
        title: "Social energy low period",
        description: "Your introverted nature suggests need for solitude",
        confidence: 0.81,
        timeframe: "today",
        impact: "low",
        actionable: true,
        suggestions: [
          "Schedule alone time",
          "Decline non-essential social events",
          "Engage in restorative activities"
        ]
      }
    ]

    return NextResponse.json(predictions)
  } catch (error) {
    console.error('Predictions API error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch predictions' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { type, context, timeframe } = await request.json()

    // Use ZAI to generate predictions
    const zai = await ZAI.create()
    
    const predictionPrompt = `
    As an AI predictive engine, analyze the user's context and generate a prediction.
    
    Type: ${type}
    Context: ${JSON.stringify(context)}
    Timeframe: ${timeframe}
    
    Provide a prediction with:
    1. Title
    2. Description
    3. Confidence score (0-1)
    4. Actionable suggestions
    5. Potential impact
    `

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an advanced AI predictive engine that analyzes user patterns and context to generate accurate, actionable predictions.'
        },
        {
          role: 'user',
          content: predictionPrompt
        }
      ],
      temperature: 0.7,
      max_tokens: 800
    })

    const aiResponse = completion.choices[0]?.message?.content || 'Prediction generated'
    
    // Parse the AI response to create a structured prediction
    const prediction = {
      id: Date.now().toString(),
      type,
      title: "AI-Generated Prediction",
      description: aiResponse,
      confidence: 0.75,
      timeframe,
      impact: "medium",
      actionable: true,
      suggestions: ["Review prediction details", "Monitor patterns", "Adjust behavior accordingly"],
      generatedAt: new Date().toISOString()
    }

    return NextResponse.json(prediction)
  } catch (error) {
    console.error('Prediction generation error:', error)
    return NextResponse.json(
      { error: 'Failed to generate prediction' },
      { status: 500 }
    )
  }
}