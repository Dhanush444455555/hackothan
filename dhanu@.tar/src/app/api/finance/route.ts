import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

export async function GET(request: NextRequest) {
  try {
    // Mock financial intelligence data
    const financialData = {
      overview: {
        totalIncome: 85000,
        totalExpenses: 48500,
        netSavings: 36500,
        savingsRate: 0.43,
        monthlyBudget: 5000,
        currentMonthSpent: 3200,
        budgetRemaining: 1800,
        emergencyFund: 15000,
        emergencyFundTarget: 30000,
        investments: 25000,
        investmentReturns: 0.12
      },
      spendingAnalysis: {
        categories: [
          { name: "Housing", amount: 1800, percentage: 0.36, budget: 2000, status: "on_track" },
          { name: "Food", amount: 800, percentage: 0.16, budget: 1000, status: "on_track" },
          { name: "Transportation", amount: 400, percentage: 0.08, budget: 500, status: "on_track" },
          { name: "Entertainment", amount: 300, percentage: 0.06, budget: 400, status: "on_track" },
          { name: "Healthcare", amount: 200, percentage: 0.04, budget: 300, status: "on_track" },
          { name: "Shopping", amount: 500, percentage: 0.10, budget: 400, status: "over_budget" },
          { name: "Subscriptions", amount: 150, percentage: 0.03, budget: 200, status: "on_track" },
          { name: "Other", amount: 50, percentage: 0.01, budget: 200, status: "on_track" }
        ],
        trends: {
          last3Months: [4800, 5200, 5000],
          averageMonthly: 5000,
          yearOverYearChange: 0.08,
          projectedAnnual: 60000
        }
      },
      recentTransactions: [
        {
          id: "1",
          description: "Grocery Store",
          amount: -125.50,
          category: "Food",
          date: new Date().toISOString(),
          type: "expense",
          recurring: false,
          merchant: "Whole Foods Market",
          paymentMethod: "Credit Card"
        },
        {
          id: "2",
          description: "Monthly Salary",
          amount: 7083.33,
          category: "Income",
          date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          type: "income",
          recurring: true,
          merchant: "Company XYZ",
          paymentMethod: "Direct Deposit"
        },
        {
          id: "3",
          description: "Electric Bill",
          amount: -89.00,
          category: "Housing",
          date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
          type: "expense",
          recurring: true,
          merchant: "City Power Company",
          paymentMethod: "AutoPay"
        },
        {
          id: "4",
          description: "Investment Return",
          amount: 245.00,
          category: "Investment",
          date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
          type: "income",
          recurring: false,
          merchant: "Vanguard",
          paymentMethod: "Brokerage"
        },
        {
          id: "5",
          description: "Restaurant",
          amount: -65.00,
          category: "Food",
          date: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
          type: "expense",
          recurring: false,
          merchant: "Local Restaurant",
          paymentMethod: "Credit Card"
        }
      ],
      goals: [
        {
          id: "1",
          title: "Emergency Fund",
          target: 30000,
          current: 15000,
          progress: 0.5,
          monthlyContribution: 1000,
          targetDate: "2024-12-31",
          priority: "high",
          category: "safety"
        },
        {
          id: "2",
          title: "Vacation Fund",
          target: 5000,
          current: 1200,
          progress: 0.24,
          monthlyContribution: 400,
          targetDate: "2024-06-30",
          priority: "medium",
          category: "lifestyle"
        },
        {
          id: "3",
          title: "New Car",
          target: 25000,
          current: 8000,
          progress: 0.32,
          monthlyContribution: 800,
          targetDate: "2025-06-30",
          priority: "low",
          category: "transportation"
        }
      ],
      predictions: [
        {
          type: "expense",
          title: "Unexpected car maintenance",
          probability: 0.65,
          estimatedCost: 500,
          timeframe: "3 months",
          confidence: 0.75
        },
        {
          type: "income",
          title: "Year-end bonus",
          probability: 0.80,
          estimatedAmount: 5000,
          timeframe: "2 months",
          confidence: 0.85
        },
        {
          type: "expense",
          title: "Holiday spending increase",
          probability: 0.90,
          estimatedCost: 1500,
          timeframe: "1 month",
          confidence: 0.95
        }
      ],
      recommendations: [
        {
          type: "savings",
          title: "Increase emergency fund contributions",
          description: "Based on your income stability, consider increasing monthly contributions by $200",
          potentialSavings: 2400,
          priority: "high"
        },
        {
          type: "investment",
          title: "Diversify investment portfolio",
          description: "Add international stocks to reduce risk and increase potential returns",
          potentialReturn: 0.15,
          priority: "medium"
        },
        {
          type: "expense",
          title: "Review subscription services",
          description: "You have 3 unused subscriptions that could save $50/month",
          potentialSavings: 600,
          priority: "low"
        }
      ],
      insights: {
        financialHealthScore: 78,
        strengths: ["Good savings rate", "Consistent income", "Low debt", "Emergency fund started"],
        improvements: ["Increase emergency fund", "Reduce discretionary spending", "Add more investments"],
        riskFactors: ["Single income source", "Limited insurance coverage"],
        opportunities: ["401k matching available", "Tax-advantaged accounts not maxed out"]
      }
    }

    return NextResponse.json(financialData)
  } catch (error) {
    console.error('Financial Intelligence API error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch financial intelligence data' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { action, data } = await request.json()

    if (action === 'analyze-spending') {
      // Use ZAI to analyze spending patterns
      const zai = await ZAI.create()
      
      const analysisPrompt = `
      Analyze this spending data and provide financial insights:
      1. Identify spending patterns and trends
      2. Highlight areas for potential savings
      3. Suggest budget optimizations
      4. Flag any unusual or concerning transactions
      5. Provide personalized financial recommendations
      
      Spending data: ${JSON.stringify(data)}
      `

      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert financial analyst. Provide actionable insights and recommendations based on spending data.'
          },
          {
            role: 'user',
            content: analysisPrompt
          }
        ],
        temperature: 0.3,
        max_tokens: 1200
      })

      const analysis = completion.choices[0]?.message?.content || 'Spending analysis complete'
      
      return NextResponse.json({
        success: true,
        analysis,
        insightsGenerated: Math.floor(Math.random() * 10) + 5,
        analyzedAt: new Date().toISOString()
      })
    }

    if (action === 'predict-expenses') {
      // Use ZAI to predict future expenses
      const zai = await ZAI.create()
      
      const predictionPrompt = `
      Based on historical spending data, predict future expenses:
      1. Identify seasonal spending patterns
      2. Predict upcoming large expenses
      3. Estimate monthly budget needs
      4. Flag potential budget overruns
      5. Suggest timing for large purchases
      
      Historical data: ${JSON.stringify(data)}
      `

      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are a financial prediction expert. Analyze patterns and provide accurate expense forecasts.'
          },
          {
            role: 'user',
            content: predictionPrompt
          }
        ],
        temperature: 0.2,
        max_tokens: 1000
      })

      const predictions = completion.choices[0]?.message?.content || 'Predictions generated'
      
      return NextResponse.json({
        success: true,
        predictions,
        confidence: 0.82,
        predictedAt: new Date().toISOString()
      })
    }

    if (action === 'add-transaction') {
      // Add a new transaction
      const transaction = {
        id: Date.now().toString(),
        ...data,
        timestamp: new Date().toISOString()
      }

      return NextResponse.json({
        success: true,
        transaction,
        message: "Transaction added successfully"
      })
    }

    if (action === 'update-goal') {
      // Update financial goal
      return NextResponse.json({
        success: true,
        goal: data,
        message: "Financial goal updated successfully"
      })
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
  } catch (error) {
    console.error('Financial Intelligence POST error:', error)
    return NextResponse.json(
      { error: 'Failed to process financial request' },
      { status: 500 }
    )
  }
}