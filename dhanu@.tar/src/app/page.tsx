'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import IntelligenceTab from '@/components/IntelligenceTab'
import LearningTab from '@/components/LearningTab'
import FinanceTab from '@/components/FinanceTab'
import ProductivityTab from '@/components/ProductivityTab'
import { 
  Brain, 
  TrendingUp, 
  Target, 
  Calendar, 
  BookOpen, 
  DollarSign, 
  Zap, 
  Bell,
  BarChart3,
  Activity,
  Clock,
  Star,
  Sparkles,
  Bot,
  Heart,
  Lightbulb,
  Settings,
  User,
  Home,
  MessageSquare
} from 'lucide-react'

interface DashboardData {
  user: {
    name: string;
    persona: string;
    mood: string;
    energy: number;
  };
  insights: {
    productivity: number;
    learning: number;
    financial: number;
    wellness: number;
  };
  predictions: Array<{
    type: string;
    title: string;
    confidence: number;
    timeframe: string;
  }>;
  tasks: Array<{
    id: string;
    title: string;
    priority: string;
    category: string;
    dueDate: string;
  }>;
  habits: Array<{
    name: string;
    streak: number;
    strength: number;
  }>;
  goals: Array<{
    title: string;
    progress: number;
    category: string;
  }>;
}

export default function Home() {
  const [data, setData] = useState<DashboardData | null>(null)
  const [activeTab, setActiveTab] = useState('overview')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Load dashboard data from API
    const loadDashboardData = async () => {
      setLoading(true)
      try {
        const response = await fetch('/api/dashboard')
        if (!response.ok) {
          throw new Error('Failed to fetch dashboard data')
        }
        const dashboardData = await response.json()
        setData(dashboardData)
      } catch (error) {
        console.error('Error loading dashboard data:', error)
        // Fallback to mock data if API fails
        setData({
          user: {
            name: "Alex Chen",
            persona: "Creative Visionary",
            mood: "Focused",
            energy: 85
          },
          insights: {
            productivity: 78,
            learning: 92,
            financial: 65,
            wellness: 88
          },
          predictions: [
            {
              type: "productivity",
              title: "Peak focus window: 2-4 PM",
              confidence: 0.87,
              timeframe: "today"
            },
            {
              type: "learning",
              title: "Optimal study session: 45 minutes",
              confidence: 0.92,
              timeframe: "today"
            },
            {
              type: "financial",
              title: "Unexpected expense likely: $50-100",
              confidence: 0.73,
              timeframe: "week"
            }
          ],
          tasks: [
            {
              id: "1",
              title: "Complete project proposal",
              priority: "high",
              category: "work",
              dueDate: "2024-01-15"
            },
            {
              id: "2",
              title: "Review machine learning course",
              priority: "medium",
              category: "learning",
              dueDate: "2024-01-16"
            },
            {
              id: "3",
              title: "Meditation session",
              priority: "low",
              category: "wellness",
              dueDate: "2024-01-14"
            }
          ],
          habits: [
            {
              name: "Morning Meditation",
              streak: 12,
              strength: 0.85
            },
            {
              name: "Reading",
              streak: 8,
              strength: 0.72
            },
            {
              name: "Exercise",
              streak: 5,
              strength: 0.68
            }
          ],
          goals: [
            {
              title: "Learn Advanced AI",
              progress: 0.65,
              category: "learning"
            },
            {
              title: "Financial Independence",
              progress: 0.42,
              category: "financial"
            },
            {
              title: "Health Optimization",
              progress: 0.78,
              category: "wellness"
            }
          ]
        })
      } finally {
        setLoading(false)
      }
    }

    loadDashboardData()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="relative w-32 h-32 mx-auto mb-8">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full animate-pulse"></div>
            <div className="absolute inset-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full animate-ping"></div>
            <div className="absolute inset-4 bg-gradient-to-r from-pink-600 to-purple-600 rounded-full flex items-center justify-center">
              <Brain className="w-12 h-12 text-white" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">AI Life Twin</h2>
          <p className="text-purple-200">Initializing your digital twin...</p>
        </div>
      </div>
    )
  }

  if (!data) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-purple-800/30 backdrop-blur-lg bg-black/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">AI Life Twin</h1>
                <p className="text-purple-200 text-sm">Your Predictive Intelligence Companion</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="text-purple-200 hover:text-white">
                <Bell className="w-4 h-4 mr-2" />
                Notifications
              </Button>
              <Button variant="ghost" size="sm" className="text-purple-200 hover:text-white">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <span className="text-white font-medium">{data.user.name}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* User Status Bar */}
        <div className="mb-8 p-6 rounded-2xl bg-gradient-to-r from-purple-800/20 to-pink-800/20 backdrop-blur-lg border border-purple-700/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <div>
                <p className="text-purple-200 text-sm">Current Persona</p>
                <p className="text-white font-semibold flex items-center">
                  <Sparkles className="w-4 h-4 mr-2 text-yellow-400" />
                  {data.user.persona}
                </p>
              </div>
              <div>
                <p className="text-purple-200 text-sm">Mood</p>
                <p className="text-white font-semibold flex items-center">
                  <Heart className="w-4 h-4 mr-2 text-pink-400" />
                  {data.user.mood}
                </p>
              </div>
              <div>
                <p className="text-purple-200 text-sm">Energy Level</p>
                <div className="flex items-center space-x-2">
                  <Progress value={data.user.energy} className="w-20 h-2" />
                  <span className="text-white font-semibold">{data.user.energy}%</span>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-green-400 text-sm">AI Active</span>
            </div>
          </div>
        </div>

        {/* Main Dashboard */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-black/30 border border-purple-700/30">
            <TabsTrigger value="overview" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              <Home className="w-4 h-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="intelligence" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              <Brain className="w-4 h-4 mr-2" />
              Intelligence
            </TabsTrigger>
            <TabsTrigger value="learning" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              <BookOpen className="w-4 h-4 mr-2" />
              Learning
            </TabsTrigger>
            <TabsTrigger value="finance" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              <DollarSign className="w-4 h-4 mr-2" />
              Finance
            </TabsTrigger>
            <TabsTrigger value="productivity" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              <Target className="w-4 h-4 mr-2" />
              Productivity
            </TabsTrigger>
            <TabsTrigger value="decisions" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              <Lightbulb className="w-4 h-4 mr-2" />
              Decisions
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Insights Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Productivity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{data.insights.productivity}%</div>
                  <Progress value={data.insights.productivity} className="mt-2 h-2" />
                  <p className="text-purple-200 text-xs mt-2">+12% from last week</p>
                </CardContent>
              </Card>

              <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
                    <BookOpen className="w-4 h-4 mr-2" />
                    Learning
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{data.insights.learning}%</div>
                  <Progress value={data.insights.learning} className="mt-2 h-2" />
                  <p className="text-purple-200 text-xs mt-2">Optimal pace maintained</p>
                </CardContent>
              </Card>

              <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
                    <DollarSign className="w-4 h-4 mr-2" />
                    Financial
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{data.insights.financial}%</div>
                  <Progress value={data.insights.financial} className="mt-2 h-2" />
                  <p className="text-purple-200 text-xs mt-2">On track with budget</p>
                </CardContent>
              </Card>

              <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="text-purple-200 text-sm font-medium flex items-center">
                    <Heart className="w-4 h-4 mr-2" />
                    Wellness
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{data.insights.wellness}%</div>
                  <Progress value={data.insights.wellness} className="mt-2 h-2" />
                  <p className="text-purple-200 text-xs mt-2">Excellent balance</p>
                </CardContent>
              </Card>
            </div>

            {/* Predictions and Tasks */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* AI Predictions */}
              <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Zap className="w-5 h-5 mr-2 text-yellow-400" />
                    AI Predictions
                  </CardTitle>
                  <CardDescription className="text-purple-200">
                    Insights based on your patterns and behavior
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {data.predictions.map((prediction, index) => (
                    <div key={index} className="p-4 rounded-lg bg-purple-800/20 border border-purple-700/30">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="secondary" className="text-xs">
                          {prediction.type}
                        </Badge>
                        <span className="text-purple-200 text-xs">
                          {Math.round(prediction.confidence * 100)}% confidence
                        </span>
                      </div>
                      <p className="text-white font-medium">{prediction.title}</p>
                      <div className="flex items-center mt-2">
                        <Clock className="w-3 h-3 mr-1 text-purple-400" />
                        <span className="text-purple-200 text-xs">{prediction.timeframe}</span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Active Tasks */}
              <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Target className="w-5 h-5 mr-2 text-blue-400" />
                    Active Tasks
                  </CardTitle>
                  <CardDescription className="text-purple-200">
                    Priority tasks for today
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {data.tasks.map((task) => (
                    <div key={task.id} className="p-3 rounded-lg bg-purple-800/20 border border-purple-700/30">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <p className="text-white font-medium">{task.title}</p>
                          <div className="flex items-center space-x-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              {task.category}
                            </Badge>
                            <span className="text-purple-200 text-xs">{task.dueDate}</span>
                          </div>
                        </div>
                        <Badge 
                          variant={task.priority === 'high' ? 'destructive' : task.priority === 'medium' ? 'default' : 'secondary'}
                          className="text-xs"
                        >
                          {task.priority}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Habits and Goals */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Habit Tracking */}
              <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Activity className="w-5 h-5 mr-2 text-green-400" />
                    Habit Tracking
                  </CardTitle>
                  <CardDescription className="text-purple-200">
                    Daily habits and consistency
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {data.habits.map((habit, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-white font-medium">{habit.name}</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-purple-200 text-sm">
                            {habit.streak} day streak
                          </span>
                          <Badge variant="secondary" className="text-xs">
                            {Math.round(habit.strength * 100)}% strength
                          </Badge>
                        </div>
                      </div>
                      <Progress value={habit.strength * 100} className="h-2" />
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Goals Progress */}
              <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Star className="w-5 h-5 mr-2 text-yellow-400" />
                    Goals Progress
                  </CardTitle>
                  <CardDescription className="text-purple-200">
                    Long-term objectives tracking
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {data.goals.map((goal, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-white font-medium">{goal.title}</span>
                        <Badge variant="outline" className="text-xs">
                          {goal.category}
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Progress value={goal.progress * 100} className="flex-1 h-2" />
                        <span className="text-purple-200 text-sm">
                          {Math.round(goal.progress * 100)}%
                        </span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Intelligence Tab */}
          <TabsContent value="intelligence" className="space-y-6">
            <IntelligenceTab />
          </TabsContent>

          {/* Learning Tab */}
          <TabsContent value="learning" className="space-y-6">
            <LearningTab />
          </TabsContent>

          {/* Finance Tab */}
          <TabsContent value="finance" className="space-y-6">
            <FinanceTab />
          </TabsContent>

              {/* Productivity Tab */}
          <TabsContent value="productivity" className="space-y-6">
            <ProductivityTab />
          </TabsContent>

          <TabsContent value="decisions" className="space-y-6">
            <Card className="bg-black/30 border-purple-700/30 backdrop-blur-lg">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Lightbulb className="w-5 h-5 mr-2 text-yellow-400" />
                  Daily Decision Intelligence
                </CardTitle>
                <CardDescription className="text-purple-200">
                  AI-powered decision support for daily choices
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Lightbulb className="w-16 h-16 mx-auto text-yellow-400 mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">Decision Module</h3>
                  <p className="text-purple-200">Smart recommendations for daily decisions coming soon...</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}